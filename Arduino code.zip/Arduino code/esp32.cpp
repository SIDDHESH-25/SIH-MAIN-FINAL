#include <Wire.h>
#include <ESP32Servo.h>
#include <Adafruit_GFX.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BMP280.h>
#include <DHT.h>
#include <TinyGPSPlus.h>
#include <Adafruit_SH110X.h>

// ==================================================
// PIN DEFINITIONS
// ==================================================
#define PAN_PIN     18
#define TILT_PIN    19
#define DHT_PIN      4
#define DHT_TYPE    DHT11
#define BUZZER_PIN  32
#define LED_PIN     33
#define GPS_RX      16
#define GPS_TX      17

// ==================================================
// OBJECT INITIALIZATION
// ==================================================
Servo panServo;
Servo tiltServo;
Adafruit_SH1106G display = Adafruit_SH1106G(128, 64, &Wire, -1);
Adafruit_MPU6050 mpu;
Adafruit_BMP280 bmp;
DHT dht(DHT_PIN, DHT_TYPE);
TinyGPSPlus gps;
HardwareSerial gpsSerial(2);

// ==================================================
// TRACKING & CONTROL VARIABLES
// ==================================================
float currentPan  = 90.0;
float currentTilt = 90.0;

// ✅ FINAL TUNED PD GAINS
float Kp = 0.10;   // Proportional gain
float Kd = 0.02;   // Derivative gain

int lastErrorX = 0;
int lastErrorY = 0;

float smoothErrorX = 0.0;
float smoothErrorY = 0.0;

// ✅ Smoothing filter
const float SMOOTHING_ALPHA = 0.5;

// ✅ Dead zone (pixels)
const int DEAD_ZONE = 10;

int lastCommandedPan  = 90;
int lastCommandedTilt = 90;

// ✅ Minimum angle change before re-commanding servo
const int MIN_ANGLE_STEP = 1;

// ==================================================
// SERVO SAFETY RANGES (CALIBRATED)
// ==================================================
#define PAN_MIN     0
#define PAN_MAX   180
#define TILT_MIN   10
#define TILT_MAX  125

// ==================================================
// TIMERS
// ==================================================
unsigned long lastSensorUpdate = 0;
unsigned long lastTargetTime   = 0;

// ==================================================
// STATUS FLAGS
// ==================================================
bool oledOK = false;
bool mpuOK  = false;
bool bmpOK  = false;

// ==================================================
// FALLBACK VALUES
// ==================================================
float lastAlt  = 0.0;
float lastGyro = 0.0;

const float SIM_ALTITUDE_M = 216.0;
const float SIM_GYRO_RADPS = 0.0;

// ==================================================
// SETUP
// ==================================================
void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println("\n\n");
  Serial.println("╔════════════════════════════════════════╗");
  Serial.println("║       HIM-KAVACH  BOOTING              ║");
  Serial.println("╚════════════════════════════════════════╝");

  // ---- GPS serial ----
  gpsSerial.begin(9600, SERIAL_8N1, GPS_RX, GPS_TX);

  // ---- IO pins ----
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  // ---- I2C bus ----
  Wire.begin(21, 22);
  Wire.setClock(100000);
  delay(500);

  // ==================================================
  // OLED INIT
  // ==================================================
  Serial.print("OLED init... ");
  if (display.begin(0x3C, true)) {
    Serial.println("✅ OK at 0x3C");
    oledOK = true;
  } else if (display.begin(0x3D, true)) {
    Serial.println("✅ OK at 0x3D");
    oledOK = true;
  } else {
    Serial.println("❌ FAILED");
  }

  if (oledOK) {
    display.clearDisplay();
    display.setTextColor(SH110X_WHITE);
    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println("HIM-KAVACH");
    display.println("Booting...");
    display.display();
  }

  // ==================================================
  // SERVOS
  // ==================================================
  Serial.print("Servos init... ");
  panServo.setPeriodHertz(50);
  tiltServo.setPeriodHertz(50);
  panServo.attach(PAN_PIN, 1000, 2000);
  tiltServo.attach(TILT_PIN, 1000, 2000);

  panServo.write((int)currentPan);
  tiltServo.write((int)currentTilt);
  delay(500);
  Serial.println("✅ OK");

  lastTargetTime = millis();

  // ==================================================
  // SENSORS
  // ==================================================
  Serial.println("Sensors init...");

  // ---- DHT11 ----
  dht.begin();
  delay(2000);
  float t = dht.readTemperature();
  if (isnan(t)) Serial.println("  ⚠️  DHT11 first read failed");
  else          Serial.printf("  ✅ DHT11 OK (%.1f°C)\n", t);

  // ---- MPU6050 ----
  if (mpu.begin()) {
    Serial.println("  ✅ MPU6050 OK");
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
    mpuOK = true;
  } else {
    Serial.println("  ⚠️  MPU6050 FAILED — using fallback");
  }

  // ---- BMP280 ----
  if (bmp.begin(0x76)) {
    Serial.println("  ✅ BMP280 OK at 0x76");
    bmpOK = true;
  } else if (bmp.begin(0x77)) {
    Serial.println("  ✅ BMP280 OK at 0x77");
    bmpOK = true;
  } else {
    Serial.println("  ⚠️  BMP280 FAILED — using fallback");
  }

  if (bmpOK) {
    bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,
                    Adafruit_BMP280::SAMPLING_X2,
                    Adafruit_BMP280::SAMPLING_X16,
                    Adafruit_BMP280::FILTER_X16,
                    Adafruit_BMP280::STANDBY_MS_500);
  }

  // Pre-load placeholder values
  lastAlt  = bmpOK ? bmp.readAltitude(1013.25) : SIM_ALTITUDE_M;
  lastGyro = SIM_GYRO_RADPS;

  // ==================================================
  // STARTUP BEEP
  // ==================================================
  digitalWrite(LED_PIN, HIGH);
  tone(BUZZER_PIN, 1000, 200);
  delay(200);
  digitalWrite(LED_PIN, LOW);

  // ==================================================
  // BOOT SUMMARY ON OLED
  // ==================================================
  if (oledOK) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println("BOOT SUMMARY");
    display.drawLine(0, 10, 127, 10, SH110X_WHITE);

    display.setCursor(0, 16);
    display.printf("OLED: %s\n", oledOK ? "OK" : "FAIL");

    display.setCursor(0, 28);
    display.printf("MPU : %s\n", mpuOK ? "OK" : "SIM");

    display.setCursor(0, 40);
    display.printf("BMP : %s\n", bmpOK ? "OK" : "SIM");

    display.setCursor(0, 52);
    display.println("Starting...");

    display.display();
    delay(2000);
  }

  Serial.println("\n=== HIM-KAVACH DevKit Ready ===\n");
}

// ==================================================
// MAIN LOOP
// ==================================================
void loop() {
  // ---- Feed GPS parser continuously ----
  while (gpsSerial.available() > 0) {
    gps.encode(gpsSerial.read());
  }

  // ==========================================
  // 1. FAST LOOP — Target Tracking
  // ==========================================
  if (Serial.available() > 0) {
    String data = Serial.readStringUntil('\n');

    if (data.startsWith("<") && data.endsWith(">")) {
      digitalWrite(LED_PIN, HIGH);
      lastTargetTime = millis();

      data = data.substring(1, data.length() - 1);
      int commaIndex = data.indexOf(',');

      if (commaIndex > 0) {
        int rawErrorX = data.substring(0, commaIndex).toInt();
        int rawErrorY = data.substring(commaIndex + 1).toInt();

        // Smooth raw error
        smoothErrorX = (SMOOTHING_ALPHA * rawErrorX) + ((1 - SMOOTHING_ALPHA) * smoothErrorX);
        smoothErrorY = (SMOOTHING_ALPHA * rawErrorY) + ((1 - SMOOTHING_ALPHA) * smoothErrorY);

        int errorX = (int)smoothErrorX;
        int errorY = (int)smoothErrorY;

        // Dead zone
        if (abs(errorX) < DEAD_ZONE) errorX = 0;
        if (abs(errorY) < DEAD_ZONE) errorY = 0;

        // Rate of change
        int errorRateX = errorX - lastErrorX;
        int errorRateY = errorY - lastErrorY;

        // PD control
        currentPan  -= (errorX * Kp) + (errorRateX * Kd);
        currentTilt += (errorY * Kp) + (errorRateY * Kd);

        lastErrorX = errorX;
        lastErrorY = errorY;

        // Clamp to mechanical limits
        currentPan  = constrain(currentPan,  PAN_MIN,  PAN_MAX);
        currentTilt = constrain(currentTilt, TILT_MIN, TILT_MAX);

        int newPan  = (int)currentPan;
        int newTilt = (int)currentTilt;

        if (abs(newPan - lastCommandedPan) >= MIN_ANGLE_STEP) {
          panServo.write(newPan);
          lastCommandedPan = newPan;
        }
        if (abs(newTilt - lastCommandedTilt) >= MIN_ANGLE_STEP) {
          tiltServo.write(newTilt);
          lastCommandedTilt = newTilt;
        }
      }

      digitalWrite(LED_PIN, LOW);
    }
  }

  // ==========================================
  // 2. FAILSAFE — Return to Center
  // ==========================================
  if (millis() - lastTargetTime > 5000) {
    float targetPan  = constrain(90.0, PAN_MIN,  PAN_MAX);
    float targetTilt = constrain(90.0, TILT_MIN, TILT_MAX);

    if (currentPan  > targetPan)  currentPan  -= 0.05;
    if (currentPan  < targetPan)  currentPan  += 0.05;
    if (currentTilt > targetTilt) currentTilt -= 0.05;
    if (currentTilt < targetTilt) currentTilt += 0.05;

    int failsafePan  = (int)currentPan;
    int failsafeTilt = (int)currentTilt;

    if (abs(failsafePan - lastCommandedPan) >= MIN_ANGLE_STEP) {
      panServo.write(failsafePan);
      lastCommandedPan = failsafePan;
    }
    if (abs(failsafeTilt - lastCommandedTilt) >= MIN_ANGLE_STEP) {
      tiltServo.write(failsafeTilt);
      lastCommandedTilt = failsafeTilt;
    }

    lastErrorX   = 0;
    lastErrorY   = 0;
    smoothErrorX = 0;
    smoothErrorY = 0;
  }

  // ==========================================
  // 3. SLOW LOOP — Sensors + OLED HUD
  // ==========================================
  if (millis() - lastSensorUpdate > 500) {
    lastSensorUpdate = millis();

    // ---- DHT11 ----
    float tempExt = dht.readTemperature();

    // ---- BMP280 ----
    float alt = 0.0;
    if (bmpOK) {
      float realAlt = bmp.readAltitude(1013.25);
      if (!isnan(realAlt)) lastAlt = realAlt;
    }
    alt = (lastAlt > 0.0) ? lastAlt : SIM_ALTITUDE_M;

    // ---- MPU6050 ----
    float gyroMag = 0.0;
    if (mpuOK) {
      sensors_event_t a, g, mpu_temp;
      mpu.getEvent(&a, &g, &mpu_temp);
      float realGyro = sqrt(sq(g.gyro.x) + sq(g.gyro.y) + sq(g.gyro.z));
      if (!isnan(realGyro)) lastGyro = realGyro;
    }
    gyroMag = lastGyro;

    // ---- Survival flags ----
    bool isFreezing = false;
    bool isShaking  = false;

    if (!isnan(tempExt) && tempExt < 22.0) {
      Kp = 0.15;
      isFreezing = true;
    } else {
      Kp = 0.10;
    }

    if (gyroMag > 1.5) {
      isShaking = true;
      tone(BUZZER_PIN, 500, 50);
    }

    if (isFreezing && !isShaking) {
      tone(BUZZER_PIN, 2000, 50);
    }

    // ---- OLED HUD ----
    if (oledOK) {
      display.clearDisplay();
      display.setTextSize(1);
      display.setCursor(0, 0);

      if (isFreezing && isShaking)      display.print("!! BLIZZARD !!");
      else if (isFreezing)              display.print("! ICE MODE !");
      else if (isShaking)               display.print("~ HIGH WIND ~");
      else                              display.print("HIM-KAVACH HUD");

      display.setCursor(0, 16);
      if (isnan(tempExt)) {
        display.print("Temp: 25.0 C");
      } else {
        display.print("Temp: "); display.print(tempExt, 1); display.print(" C");
      }

      display.setCursor(0, 28);
      if (isShaking) {
        display.print("Vib : "); display.print(gyroMag, 2); display.print(" r/s");
      } else {
        display.print("Alt : "); display.print(alt, 1); display.print(" m");
      }

      display.setCursor(0, 40);
      display.print("GPS : ");
      if (gps.location.isValid())              display.print("LOCKED");
      else if (gps.charsProcessed() < 10)      display.print("NO DATA");
      else                                      display.print("SEARCHING");

      display.setCursor(0, 52);
      display.print("Kp: "); display.print(Kp, 3);
      display.print(" Kd: "); display.print(Kd, 3);

      display.display();
    }
  }
}s